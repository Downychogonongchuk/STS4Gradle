package com.icia.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.icia.board.service.MemberService;

@RestController
public class BoardRestController {
	@Autowired
	private MemberService mServ;
}
